package com.example.notatki;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Notatka> notes;
    private ArrayAdapter<Notatka> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView notesListView = findViewById(R.id.notesListView);
        EditText titleEditText = findViewById(R.id.titleEditText);
        EditText contentEditText = findViewById(R.id.contentEditText);
        Button addButton = findViewById(R.id.addButton);

        notes = new ArrayList<>();
        notes.add(new Notatka("tenis", "Gra z Ewą w poniedziałek", true));

        arrayAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                notes
        );
        notesListView.setAdapter(arrayAdapter);

        addButton.setOnClickListener(v -> {
            String tytul = titleEditText.getText().toString();
            String tresc = contentEditText.getText().toString();

            notes.add(new Notatka(tytul, tresc, false));
            arrayAdapter.notifyDataSetChanged();

            titleEditText.setText("");
            contentEditText.setText("");
        });
    }
}