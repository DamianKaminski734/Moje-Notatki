package com.example.notatki;

import java.util.Date;

public class Notatka {
    public String tytul;
    public String tresc;
    public boolean czyWazna;
    public Date dataDodania;

    public Notatka(String tytul, String tresc, boolean czyWazna) {
        this.tytul = tytul;
        this.tresc = tresc;
        this.czyWazna = czyWazna;
        this.dataDodania = new Date();
    }

    public Notatka(String tytul) {
        this.tytul = tytul;
        this.tresc = "";
        this.czyWazna = false;
        this.dataDodania = new Date();
    }

    @Override
    public String toString() {
        return tytul + "\n" + tresc;
    }
}